if ( wgNamespaceNumber == 14 ) $j(document).ready(function(){
    addPortletLink('p-tb', 'http://toolserver.org/~magnus/catfood.php?category=' + encodeURIComponent (wgTitle.split(" ").join("_")), 'Category RSS feed', 't-catfood', null);
});